#
# name ='thierry'
# age=22
# is_new=True
#
# print(name)
#
# department= input('what is your department')
# print(department)
#
# names= input('what is your name')
# color= input('what is your favorate color')
# print(name + '  likes  '+ color)
# birth_year= input('what is your birth year')
# current_year= input('what is the current year')
# age=int(current_year)- int(birth_year)

#print(age)
course="'hi  my friend , how are you \
      are you okay?'"
print(course)



name ='mr wyatt'
if len(name)<3:
    print('name must be have character more than 3')
elif len(name)>50:
    print('name must not have the character more than 50')
else:
    print('the name is realy')
weight = input('weight')
unit = input(''(L'bs or (K)g :')
if unit.upper() =="L":
    converted= weight *0.45
    print(f"you are {converted}kilos")
    else:
        converted= weight/0.45
        print(f"you are {converted}pounds")